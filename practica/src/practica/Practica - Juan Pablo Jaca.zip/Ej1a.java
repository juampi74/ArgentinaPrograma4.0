package practica;

public class Ej1a {

	public static void main(String[] args) {
		int numeroInicio = 5;
		int numeroFin = 14;
			
		int num = numeroInicio;
			
		while(num <= numeroFin) {
			System.out.println(num);
			num++;
		}
	}
}
